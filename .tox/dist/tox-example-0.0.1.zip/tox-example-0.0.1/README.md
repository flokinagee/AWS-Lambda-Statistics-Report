# MyPublicRepo

How to generate the report on AWS Lambda Statistics - In Progress

class LambdaStatisticsExceptions(Exception):
    ''' Base scripts '''
    pass
